export interface CartItems {
    [itemId: number]: {
        quantity: number;
    };
}
