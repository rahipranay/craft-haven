const Footer = () => {
    return (
        <div className="copyright">
            &copy; CraftHaven Store. All rights reserved.
        </div>
    );
};

export default Footer;
