import { Outlet } from "react-router-dom";

const PageContainer = () => {
    return <Outlet />;
};

export default PageContainer;
